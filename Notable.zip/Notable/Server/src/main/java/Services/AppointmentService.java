package Services;

import DAO.AppointmentDAO;
import Model.Appointment;
import Responses.AppointmentResponse;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.UUID;

public class AppointmentService {
    public static AppointmentResponse getAppointments(LocalDateTime date, UUID docId) {
        AppointmentDAO aptDao = new AppointmentDAO();
        ArrayList<Appointment> aptList = aptDao.getAppointments(date, docId);
        if(aptList != null){
            return new AppointmentResponse(aptList, true);
        }

        return new AppointmentResponse(null, false);
    }

    public static AppointmentResponse createAppointment(LocalDateTime date, UUID docId, String pFirstName, String pLastName, boolean newPatient) {
        AppointmentDAO aptDao = new AppointmentDAO();
        ArrayList<Appointment> aptList = aptDao.createAppointments(date, docId, pFirstName, pLastName, newPatient);
        if(aptList != null){
            return new AppointmentResponse(aptList, true);
        }

        return new AppointmentResponse(null, false);
    }

    public static AppointmentResponse deleteAppointment(UUID aptID) {
        AppointmentDAO aptDao = new AppointmentDAO();
        return new AppointmentResponse(null, aptDao.deleteAppointment(aptID));
    }
}
