package Services;

import Responses.UserResponse;

import java.util.UUID;

public class UserService {

    public UserResponse getUserById(UUID userId){
        return new UserResponse(userId, "Parker", "Murray", true);
    }
}
