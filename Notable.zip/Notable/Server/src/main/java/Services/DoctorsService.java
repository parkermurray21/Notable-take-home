package Services;


import DAO.DoctorDAO;
import Model.Doctor;
import Responses.DoctorResponse;
import Responses.DoctorsResponse;

import java.util.ArrayList;
import java.util.UUID;

public class DoctorsService {

    public DoctorsResponse getAllDoctors(){
        DoctorDAO doctorDAO = new DoctorDAO();
        ArrayList<Doctor> docList = doctorDAO.getAllDoctors();
        if(docList != null){
            return new DoctorsResponse(docList, true);
        }
        return new DoctorsResponse(null, false);
    }

}
