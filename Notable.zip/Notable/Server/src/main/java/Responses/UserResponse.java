package Responses;

import java.util.UUID;

public class UserResponse {
    private UUID userId;
    private String firstName;
    private String lastName;
    private boolean wasSuccess;

    public UserResponse(UUID userId, String firtName, String lastName, boolean wasSuccess){
        this.userId = userId;
        this.firstName = firtName;
        this.lastName = lastName;
        this.wasSuccess = wasSuccess;
    }

    public UUID getUserId() {
        return userId;
    }

    public void setUserId(UUID userId) {
        this.userId = userId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public boolean wasSuccessful() {
        return wasSuccess;
    }
}
