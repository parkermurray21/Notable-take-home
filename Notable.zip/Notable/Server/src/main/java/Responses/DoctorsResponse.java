package Responses;

import Model.Doctor;

import java.util.ArrayList;

public class DoctorsResponse {
    private ArrayList<Doctor> doctorsList;
    private boolean wasSuccesful;

    public DoctorsResponse(ArrayList<Doctor> docList, boolean wasSuccesful){
       this.doctorsList = docList;
       this.wasSuccesful = wasSuccesful;
    }

    public boolean wasSuccessful(){
        return wasSuccesful;
    }
}
