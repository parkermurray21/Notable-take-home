package Responses;

import Model.Appointment;

import java.util.ArrayList;

public class AppointmentResponse {
    private ArrayList<Appointment> aptList;
    private boolean wasSuccessful;
    public AppointmentResponse(ArrayList<Appointment> aptList, boolean wasSuccessful) {
        this.aptList = aptList;
        this.wasSuccessful = wasSuccessful;
    }

    public boolean wasSuccessful(){
        return wasSuccessful;
    }
}
