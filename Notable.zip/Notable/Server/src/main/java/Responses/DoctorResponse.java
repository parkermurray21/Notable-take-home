package Responses;

import java.util.UUID;

public class DoctorResponse {
    private UUID doctorId;
    private String firstName;
    private String lastName;
    private boolean wasSuccess;

    public DoctorResponse(UUID doctorId, String firtName, String lastName, boolean wasSuccess){
        this.doctorId = doctorId;
        this.firstName = firtName;
        this.lastName = lastName;
        this.wasSuccess = wasSuccess;
    }

    public UUID getDoctorIdId() {
        return doctorId;
    }

    public void setDoctorId(UUID userId) {
        this.doctorId = userId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public boolean wasSuccessful() {
        return wasSuccess;
    }
}
