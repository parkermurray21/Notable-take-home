package Model;
import java.util.UUID;

public class Doctor {
    private UUID doctorID;
    private String firstName;
    private String lastName;

    public Doctor(UUID doctorID, String firstName, String lastName) {
        this.doctorID = doctorID;
        this.firstName = firstName;
        this.lastName = lastName;
    }
}
