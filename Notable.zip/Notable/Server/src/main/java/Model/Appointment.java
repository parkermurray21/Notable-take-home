package Model;
import java.time.LocalDateTime;
import java.util.UUID;

public class Appointment {
    private UUID appointmentId;
    private UUID doctorId;
    private String patientFirstName;
    private String patientLastName;
    private boolean isNewPatient;
    private LocalDateTime dateTime;

    public UUID getAppointmentId() {
        return appointmentId;
    }

    public void setAppointmentId(UUID appointmentId) {
        this.appointmentId = appointmentId;
    }

    public UUID getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(UUID doctorId) {
        this.doctorId = doctorId;
    }

    public String getPatientFirstName() {
        return patientFirstName;
    }

    public void setPatientFirstName(String patientFirstName) {
        this.patientFirstName = patientFirstName;
    }

    public String getPatientLastName() {
        return patientLastName;
    }

    public void setPatientLastName(String patientLastName) {
        this.patientLastName = patientLastName;
    }

    public boolean isNewPatient() {
        return isNewPatient;
    }

    public void setNewPatient(boolean newPatient) {
        isNewPatient = newPatient;
    }

    public LocalDateTime getDateTime() {
        return dateTime;
    }

    public void setDateTime(LocalDateTime dateTime) {
        this.dateTime = dateTime;
    }



    public Appointment(UUID appointmentId, UUID doctorId, String patientFirstName, String patientLastName, boolean isNewPatient, LocalDateTime dateTime) {
        this.appointmentId = appointmentId;
        this.doctorId = doctorId;
        this.patientFirstName = patientFirstName;
        this.patientLastName = patientLastName;
        this.isNewPatient = isNewPatient;
        this.dateTime = dateTime;
    }



}
