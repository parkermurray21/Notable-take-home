package DAO;

import Model.Appointment;
import Responses.AppointmentResponse;

import java.lang.reflect.Array;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.UUID;

public class AppointmentDAO {
    private Appointment apt1 = new Appointment(UUID.randomUUID(), UUID.fromString("ae6c333c-a8d2-4baf-9931-09e16d57699d"), "Connor", "Morin", true, LocalDateTime.of(2022, 8, 11, 8, 0, 0));
    private Appointment apt2 = new Appointment(UUID.randomUUID(), UUID.fromString("ae6c333c-a8d2-4baf-9931-09e16d57699d"), "Shelby", "Murray", true, LocalDateTime.of(2022, 8, 11, 8, 0, 0));
    private Appointment apt3 = new Appointment(UUID.randomUUID(), UUID.fromString("ae6c333c-a8d2-4baf-9931-09e16d57699d"), "kiley", "ore", false, LocalDateTime.of(2022, 8, 11, 8, 15, 0));
    private Appointment apt4 = new Appointment(UUID.randomUUID(), UUID.fromString("b7a903b3-0bdb-41fa-ae65-d6bb06fdbe36"), "Kira", "Warnick", false, LocalDateTime.of(2022, 8, 14, 8, 15, 0));

    private static ArrayList<Appointment> aptList = new ArrayList<>();

    public ArrayList<Appointment> getAppointments(LocalDateTime date, UUID docId) {
        System.out.println("made it to aptDAO");
        aptList.add(apt1);
        aptList.add(apt2);
        aptList.add(apt3);
        aptList.add(apt4);

        ArrayList<Appointment> docAndDateApts = new ArrayList<>();

        for(Appointment apt : aptList){ //filtering for doc and date
            if(apt.getDateTime().getDayOfYear() == date.getDayOfYear() && apt.getDateTime().getYear() == date.getYear() && apt.getDoctorId().toString().equals(docId.toString())){
                docAndDateApts.add(apt);
            }

        }
        return docAndDateApts;
    }

    public ArrayList<Appointment> createAppointments(LocalDateTime date, UUID docId, String pFirstName, String pLastName, boolean newPatient) {
        if(validateDateOpening(date, docId)){
            Appointment newApt = new Appointment(UUID.randomUUID(), docId, pFirstName, pLastName, newPatient, date);
            System.out.println("adding to aptList");
            aptList.add(newApt);
            ArrayList<Appointment> newApts = new ArrayList<>();
            newApts.add(newApt);
            return newApts;
        }
        return null;
    }

    private Boolean validateDateOpening(LocalDateTime date, UUID docID){
        int aptCount = 0;

        if((date.getMinute()%15) != 0){ //this acts as a filter for the minute problem --> mod 15 prevents any non approved times to get in
            return false;
        }
        for(Appointment apt : aptList){ //checking for apts for that doc and time if the count is greater than or equal to 3 not valid
            if(apt.getDoctorId().toString().equals(docID.toString())){
                if(apt.getDateTime().equals(date)){
                    aptCount++;
                }
            }
        }
        if(aptCount >= 3){
            return false;
        }
        return true;
    }

    public Boolean deleteAppointment(UUID aptId){ //simply deleting the apt based on aptId
        return aptList.removeIf(apt -> apt.getAppointmentId().equals(aptId));
    }
}
