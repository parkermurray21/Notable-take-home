package DAO;

import Model.Doctor;

import java.util.ArrayList;
import java.util.UUID;

public class DoctorDAO {
    private final Doctor doc1 = new Doctor(UUID.fromString("ae6c333c-a8d2-4baf-9931-09e16d57699d"),"Parker", "Murray");
    private Doctor doc2 = new Doctor(UUID.fromString("b7a903b3-0bdb-41fa-ae65-d6bb06fdbe36"),"John", "Smith");
    private Doctor doc3 = new Doctor(UUID.fromString("9d3d7f3a-f3f3-446d-b4d7-cd2b8a538c89"), "Caiden", "Brown");
    private Doctor doc4 = new Doctor(UUID.fromString("f8aa932c-d05b-4966-a085-25b0bb25ae7c"), "Houston", "Turley");
    private Doctor doc5 = new Doctor(UUID.fromString("d18e7ad7-b46d-4e06-ad9f-2e9b51f04842"), "Jess", "Carter");

    public static ArrayList<Doctor> docList = new ArrayList<>();

    public ArrayList<Doctor> getAllDoctors() {
        docList.add(doc1);
        docList.add(doc2);
        docList.add(doc3);
        docList.add(doc4);
        docList.add(doc5);
        return docList;
    }
}
