import java.io.IOException;

import Handlers.AppointmentHandler;
import Handlers.DoctorsHandler;
import com.sun.net.httpserver.HttpServer;

import java.net.InetSocketAddress;


public class Server {
    private static int PORT = 8080;
    private static HttpServer Server;
    private static int NumOfMaxConnections = 1000;

    public static void main(String[] args){

        if(args.length > 0){
            Integer temp = Integer.parseInt(args[0]);
            PORT = temp;
        }

        try {
            System.out.println("Calling HttpServer.create method!");
            Server = HttpServer.create(new InetSocketAddress(PORT), NumOfMaxConnections);
            System.out.println("Create Server completed successfully");

        } catch (IOException error) {
            error.printStackTrace();
            return;
        }
        Server.createContext("/doctors", new DoctorsHandler());
        Server.createContext("/appointments", new AppointmentHandler());
        Server.start();
        System.out.println("server is running on port " + PORT);

    }

}

