package Handlers;


import Responses.AppointmentResponse;
import Responses.DoctorsResponse;
import Responses.UserResponse;
import Services.AppointmentService;
import Services.DoctorsService;
import Services.UserService;
import com.google.gson.Gson;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;


public class AppointmentHandler implements HttpHandler {

    @Override
    public void handle(HttpExchange httpExchange) throws IOException {
        System.out.println("inside Apt Handler");
        String query = httpExchange.getRequestURI().toString();
        String requestMethod = httpExchange.getRequestMethod();
        System.out.println(requestMethod);
        Map<String, String> params = queryToMap(query);
        Gson gson = new Gson();
        String JSON = "";
        AppointmentResponse AR = new AppointmentResponse(null, false);
        if(requestMethod.equals("POST")){
            boolean newPatient = false;
            if(Objects.equals(params.get("newPatient"), "true")){
                newPatient = true;
            }
            AR = createNewAppointAppointment(LocalDateTime.parse(params.get("date")), UUID.fromString(params.get("docID")), params.get("pFirstName"), params.get("pLastName"), newPatient);
        }else if(requestMethod.equals("DELETE")){
            AR = handleDeleteAppointment(UUID.fromString(params.get("aptID")));
        }
        else{
            if(params.containsKey("date") && params.containsKey("docID")){
                AR = getAppointmentByDocAndDate(LocalDateTime.parse(params.get("date")), UUID.fromString(params.get("docID")));
            }
        }
        if(AR.wasSuccessful()){
            httpExchange.sendResponseHeaders(200, 0);
            JSON = gson.toJson(AR);
        } else{
            httpExchange.sendResponseHeaders(400, 0);
            JSON = "An Error occured while trying to fulfill your request";
        }
        OutputStream res = httpExchange.getResponseBody();
        OutputStreamWriter StreamWriter = new OutputStreamWriter(res);
        StreamWriter.write(JSON);
        StreamWriter.flush();
        res.close();
        return;

    }

    private AppointmentResponse handleDeleteAppointment(UUID aptID) {
        return AppointmentService.deleteAppointment(aptID);
    }

    private AppointmentResponse getAppointmentByDocAndDate(LocalDateTime date, UUID docId) {
        return AppointmentService.getAppointments(date, docId);
    }

    private AppointmentResponse createNewAppointAppointment(LocalDateTime date, UUID docId, String pFirstName, String pLastName, boolean newPatient) {
        return AppointmentService.createAppointment(date, docId, pFirstName, pLastName, newPatient);
    }

    public Map<String, String> queryToMap(String query) {
        if(query == null) {
            return null;
        }
        String[] urlQueryArr = query.split("\\?");
        query = urlQueryArr[1];
        Map<String, String> result = new HashMap<>();
        for (String param : query.split("&")) {
            String[] entry = param.split("=");
            if (entry.length > 1) {
                result.put(entry[0], entry[1]);
            }else{
                result.put(entry[0], "");
            }
        }
        return result;
    }
}
