package Handlers;


import Responses.DoctorsResponse;
import Responses.UserResponse;
import Services.DoctorsService;
import Services.UserService;
import com.google.gson.Gson;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.*;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;


public class DoctorsHandler implements HttpHandler {

    @Override
    public void handle(HttpExchange httpExchange) throws IOException {
        System.out.println("inside Doctors Handler");
        Gson gson = new Gson();
        String JSON = "";
        DoctorsResponse DR = handleAllDoctors();
        if(DR.wasSuccessful()){
            httpExchange.sendResponseHeaders(200, 0);
            JSON = gson.toJson(DR);
        }
        OutputStream res = httpExchange.getResponseBody();
        OutputStreamWriter StreamWriter = new OutputStreamWriter(res);
        StreamWriter.write(JSON);
        StreamWriter.flush();
        res.close();
        return;
    }

    private DoctorsResponse handleAllDoctors(){
        DoctorsService DS = new DoctorsService();
        return DS.getAllDoctors();
    }

    private UserResponse handleAllPersons(String at) {
        System.out.println("Got here4");
        UserService US = new UserService();
        //UserResponse UR =  new UserResponse();//US.getAllPersons(at);
        return null;
    }

    public UserResponse handleUserById(UUID userID){
        System.out.println("inside handleUserById");
        UserService US = new UserService();
        UserResponse UR = US.getUserById(userID);
        return UR;
    }

    public Map<String, String> queryToMap(String query) {
        if(query == null) {
            return null;
        }
        String[] urlQueryArr = query.split("\\?");
        query = urlQueryArr[1];
        Map<String, String> result = new HashMap<>();
        for (String param : query.split("&")) {
            String[] entry = param.split("=");
            if (entry.length > 1) {
                result.put(entry[0], entry[1]);
            }else{
                result.put(entry[0], "");
            }
        }
        return result;
    }
}
